//comentario corto - una sola linea

/* 
comentario
mas
extenso
aqui
*/

//declaracion de una variable
let equipo;
//inicializacion de la variable
equipo = 'Manchester city'; //string o cadena de texto

//declaracion e inicializacion de una variable
let jugadores = 11; //number o dato numerico 
//actualizo el valor de jugadores
jugadores = 22;

//constantes
const DESCUBRIMIENTO = 1492;

//camelCase
let miAuto='Ford';

//OPERADORES MATEMATICOS
//SUMA +
let suma = 5 + 2;
//RESTA -
let resta = 5 - 2;
//MULTIPLICACION *
let multip = 5 * 2;
//DIVISION /
let division = 5 / 2;

//calculo con otra variable
let jugadoresEnCancha = jugadores - 11;


//CONCATENACION de strings
let oracion = 'Mi equipo es: '+equipo;//Mi equipo es: Manchester city
let oracion2 = miAuto +' es lo mejor';//Ford es lo mejor

//Salida de datos por consola
console.log(oracion);
console.log('El resultado de la suma es: '+suma);
console.log('EL resultado de la division es: '+division);
console.log('Los jugadores en cancha son: '+jugadoresEnCancha);

//salida de datos por alert
/* alert('El resultado de la suma es: '+suma);
alert('Los jugadores en cancha son: '+jugadoresEnCancha); */

//entrada de datos por prompt - toma todo en formato string
let nombre = prompt('Ingresa tu nombre');

//dar la bienvenida
alert('Te damos la bienvenida a JavaScript, '+nombre);

//otro ejemplo
let anioNacim = parseInt(prompt('Ingresa el año de tu nacimiento'));//1990 ahora ya es un numero
let edad = 2024 - anioNacim;

alert(nombre + ' este año cumpliste o cumpliras '+ edad + ' años');

//otro ejemplo
let precioProducto = parseFloat(prompt('Ingresa el precio del producto a comprar'));//1999.99
let dineroEnCuenta = 100000;
let resto = dineroEnCuenta - precioProducto;

alert('Tienes en cuenta $'+ resto);
